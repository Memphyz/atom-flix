---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## 🚀 Feature request

### Problem description

Describe what you'd like to be able to accomplish. Including a rough sketch or screenshot can be helpful.

### Suggested solution (optional)

Suggest a solution that would solve the problem you have. For example, this may involve adding a new prop, changing an existing prop, or adding a new exported component.
