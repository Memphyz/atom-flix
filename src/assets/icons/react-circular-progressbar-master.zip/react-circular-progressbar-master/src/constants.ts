export const VIEWBOX_WIDTH = 100;
export const VIEWBOX_HEIGHT = 100;
export const VIEWBOX_HEIGHT_HALF = 50;
export const VIEWBOX_CENTER_X = 50;
export const VIEWBOX_CENTER_Y = 50;
